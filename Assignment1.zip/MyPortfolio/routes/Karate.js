"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var assert = require("assert");
function Test1() {
    assert.ok(true, "This shouldn't fail");
}
exports.Test1 = Test1;
function Test2() {
    assert.ok(1 === 1, "This shouldn't fail");
    assert.ok(false, "This should fail");
}
exports.Test2 = Test2;
/*
 * GET users listing.
 */
var express = require("express");
var router = express.Router();
router.get('/', function (req, res) {
    var message = "When I was 8 years old, I was invited by a school friend to a bring-your-friend to class session at Lewis' Karate School in Barrie, (the one near Huronia), and I enjoyed it. In November 2005, I started training there as a White Belt. Now, I am proud to say I've gotten my first degree Black Belt at the age of 12, and my second degree at the age of 15.";
    var message = "Unfortunately, during my freshman year of college, I had trouble balancing my karate lessons with schoolwork, attending lectures, as well as situations regarding my family and medical health. So, in the month of December 2017, my parents and I stopped my attending LKS (Lewis' Karate School') so I could recover from my sickness but also continue my education.";
    var message = "In Spring 2019, I took a GNED Course my college offered on Tai Chi, as it is a martial art and a way to recover from certain pains or sickness. Since I picked up a viral bug and flu, and developed costochondritis, my parents and I figured that this would make a good choice for my final required GNED course and a way to get rid of my sickness. I never missed a class, and I received an 'A' by the end of that course. I still try to attempt to perform it at home, but it takes a little while and effort. Hopefully, it'll one day help me regain the phsyical stature I need to resume my studies in Karate.";
    var message = "Going to Lewis' Karate School didn't just help me physically; ";
    res.render("Karate", { key: message });
});
exports.default = router;
//# sourceMappingURL=Karate.js.map