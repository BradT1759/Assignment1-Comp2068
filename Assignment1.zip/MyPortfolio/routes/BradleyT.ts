﻿import assert = require('assert');

export function Test1() {
    assert.ok(true, "This shouldn't fail");
}

export function Test2() {
    assert.ok(1 === 1, "This shouldn't fail");
    assert.ok(false, "This should fail");
}

/*
 * GET users listing.
 */
import express = require('express');
const router = express.Router();

router.get('/', (req: express.Request, res: express.Response) => {
    var message = "Hello, I'm Bradley Tobin. This website features facts about me and my interests in and outside of work.";
    res.render("index", { key: message });
});

export default router;