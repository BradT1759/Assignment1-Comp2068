﻿import assert = require('assert');

export function Test1() {
    assert.ok(true, "This shouldn't fail");
}

export function Test2() {
    assert.ok(1 === 1, "This shouldn't fail");
    assert.ok(false, "This should fail");
}

/*
 * GET users listing.
 */
import express = require('express');
const router = express.Router();

router.get('/', (req: express.Request, res: express.Response) => {
    var message = "I am a fan of Transformers, Ben 10, Power Rangers, DC Comics, Marvel Comics, Star Wars and Star Trek. I like to write novels and I'm a blackbelt second degree.";
    res.render("AboutMe", { key: message });
});

export default router;